<?php 

class Model_city extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function getCityData($cityId = null) 
	{
		if($cityId) {
			$sql = "SELECT * FROM city WHERE cityId = ?";
            $query = $this->db->query($sql, array($cityId));
		      return $query->row_array();
			
		}

		$sql = "SELECT * FROM city WHERE cityId != ?";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}

/*	public function getUserGroup($userId = null) 
	{
		if($userId) {
			$sql = "SELECT * FROM user_group WHERE user_id = ?";
			$query = $this->db->query($sql, array($userId));
			$result = $query->row_array();

			$group_id = $result['group_id'];
			$g_sql = "SELECT * FROM groups WHERE id = ?";
			$g_query = $this->db->query($g_sql, array($group_id));
			$q_result = $g_query->row_array();
			return $q_result;
		}
	}*/
public function create($data = '', $group_id = null)
	{

		if($data) {
			$create = $this->db->insert('city', $data);

			

			return ($create == true ) ? true : false;
		}
		
	}

	public function edit($data = array(), $cityId = null)
	{
		$this->db->where('cityId', $cityId);
		$update = $this->db->update('city', $data);


			
		return ($update == true) ? true : false;	
	}

	public function delete($cityId)
	{
		$this->db->where('cityId', $cityId);
		$delete = $this->db->delete('city');
		return ($delete == true) ? true : false;
	}

	public function countTotalAgent()
	{
		$sql = "SELECT * FROM city";
		$query = $this->db->query($sql);
		return $query->num_rows();
	}
	
}