<?php 

class Model_invoice extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getActiveReport()
	{
		$sql = "SELECT reports.*,agent.agentName FROM reports left join agent on agent.agentId = reports.agentId ";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}
	public function getReportData($reportId = null) 
	{
		if($reportId) {
			$sql = "SELECT * FROM reports WHERE reportId = ?";
			$query = $this->db->query($sql, array($reportId));
			return $query->row_array();
		}

		$sql = "SELECT * FROM reports WHERE reportId != ?";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}



	public function create($data = '', $group_id = null)
	{

		if($data) {
			$create = $this->db->insert('reports', $data);

			   
$sql = "SELECT MAX(reportId) as reportId FROM reports";
			$query = $this->db->query($sql);
			//print_r($query->row_array());die;
			return ($create == true ) ? $query->row_array() : false;
		}
	}

	public function edit($data = array(), $reportId = null)
	{
		$this->db->where('reportId', $reportId);
		$update = $this->db->update('reports', $data);


			
		return ($update == true) ? true : false;	
	}

	public function delete($reportId)
	{
		$this->db->where('reportId', $reportId);
		$delete = $this->db->delete('reports');
		return ($delete == true) ? true : false;
	}

	public function countTotalReport()
	{
		$sql = "SELECT * FROM reports";
		$query = $this->db->query($sql);
		return $query->num_rows();
	}
	
}