<?php 

class Model_agent extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getActiveAgent()
	{
		$sql = "SELECT * FROM agent";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}
	public function getAgentData($agentId = null) 
	{
		if($agentId) {
			$sql = "SELECT * FROM agent WHERE agentId = ?";
			$query = $this->db->query($sql, array($agentId));
			return $query->row_array();
		}

		$sql = "SELECT * FROM agent WHERE agentId != ?";
		$query = $this->db->query($sql, array(1));
		return $query->result_array();
	}



	public function create($data = '', $group_id = null)
	{

		if($data) {
			$create = $this->db->insert('agent', $data);

			

			return ($create == true ) ? true : false;
		}
	}

	public function edit($data = array(), $agentId = null)
	{
		$this->db->where('agentId', $agentId);
		$update = $this->db->update('agent', $data);


			
		return ($update == true) ? true : false;	
	}

	public function delete($agentId)
	{
		$this->db->where('agentId', $agentId);
		$delete = $this->db->delete('agent');
		return ($delete == true) ? true : false;
	}

	public function countTotalAgent()
	{
		$sql = "SELECT * FROM agent";
		$query = $this->db->query($sql);
		return $query->num_rows();
	}
	
}