<?php 

class Reports extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();
		
		$this->data['page_title'] = 'Reports';
		$this->load->model('model_agent');
	$this->load->model('model_products');
		$this->load->model('model_reports');
	//	$this->load->model('model_groups');
	}

	
	public function index()
	{
		
		

		$report_data = $this->model_reports->getActiveReport();
//echo "<pre>";print_r($report_data);die;
		

		$this->data['report_data'] = $report_data;
		$product = $this->model_products->getProductData();
		
		foreach($product as $key => $val){
		$productArr[$val['id']] = 	$val['name'];
		}
		
		$this->data['product'] = $productArr;
		//echo "<pre>";print_r($this->data);die;
		$this->render_template('reports/index', $this->data);
	}

	public function create()
	{


		
		$this->form_validation->set_rules('purchaseproduct', 'purchaseproduct','trim|required');
		$this->form_validation->set_rules('purchaseQty', 'purchaseQty', 'trim|required');
	//	$this->form_validation->set_rules('agent', 'agent', 'trim|required');
		;
        if ($this->form_validation->run() == TRUE) {
            // true case
         //   $password = $this->password_hash($this->input->post('password'));
        	$data = array(
        		'purchaseproduct' => $this->input->post('purchaseproduct'),
        		'purchaseQty' => $this->input->post('purchaseQty'),
				'saleproduct' => $this->input->post('saleproduct'),
        		'saleQty' => $this->input->post('saleQty'),
				'agentId' => ($this->input->post('agent')),
				
        	
        	);

        	$create = $this->model_reports->create($data, $this->input->post('groups'));
			
			//echo "";print_r($create);die;
        	if($create) {
				$dataupdate['invoiceId'] = 'INV-'.date('Y').'-'.date('m').'-'.$create['reportId'];
				 $this->model_reports->edit($dataupdate, $create['reportId']);
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('reports/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('reports/create', 'refresh');
        	}
        }
        else {
            // false case
        	$this->data['agent'] = $this->model_agent->getActiveAgent(); 
			$this->data['product'] = $this->model_products->getProductData(); 
			//echo "<pre>";print_r($this->data);die;
            $this->render_template('reports/create', $this->data);
        }	
		

		
	}

public function edit($reportId)
	{


		
		$this->form_validation->set_rules('sale', 'sale','trim|required');
		$this->form_validation->set_rules('', 'purchase', 'trim|required');
	//	$this->form_validation->set_rules('agent', 'agent', 'trim|required');
		;
        if ($this->form_validation->run() == TRUE) {
            // true case
         //   $password = $this->password_hash($this->input->post('password'));
        	$data = array(
        		'sale' => $this->input->post('sale'),
        		
        		'purchase' => $this->input->post('purchase'),
				'agentId' => ($this->input->post('agent')),
        	
        	);

        	$create = $this->model_reports->edit($data, $reportId);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('reports/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('reports/edit', 'refresh');
        	}
        }
        else {
            // false case
			$product_data = $this->model_reports->getReportData($reportId);
            $this->data['product_data'] = $product_data;
        	 $this->data['agent'] = $this->model_agent->getActiveAgent(); 
        	 $this->data['product'] = $this->model_products->getProductData(); 
			 
            $this->render_template('reports/edit', $this->data);
        }	
		

		
	}

public function delete($reportId)
	{
		
		if($reportId) {
			//echo"<pre>"; print_r($reportId);die;
			if($this->input->post('confirm')) {
					$delete = $this->model_reports->delete($reportId);
					if($delete == true) {
		        		$this->session->set_flashdata('success', 'Successfully removed');
		        		redirect('reports/', 'refresh');
		        	}
		        	else {
		        		$this->session->set_flashdata('error', 'Error occurred!!');
		        		redirect('reports/delete/'.$reportId, 'refresh');
		        	}

			}	
			else {
				$this->data['reportId'] = $reportId;
				$this->render_template('reports/delete', $this->data);
			}	
		}
	}


}