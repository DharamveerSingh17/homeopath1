<?php //echo "<pre>";print_r($product_data);die;?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Manage
      <small>Reports</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Reports</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-md-12 col-xs-12">
	  <h5>invoiceId: <?php echo $report_data['invoiceId'];?></h5>
	  Agent Name :<?php echo $report_data['agentName'];?>
	 <br> Address    :
	 <br> phone      :
	  

	     <br /> <br/>
                <table class="table" id="product_info_table">
                  <thead>
                    <tr>
                      <th style="width:20%">purchase product</th>
                      <th style="width:10%">purchase Qty</th>
                      <th style="width:10%">sale product</th>
                      <th style="width:20%">sale Qty</th>
                    </tr>
                  </thead>

       <tbody>
                  <?php if($report_data): ?>                  
                    <?php foreach ($report_data as $k => $v): ?>
                      <tr>
                        <td><?php echo $product[$v['purchaseproduct']]; ?></td>
						 <td><?php echo $product[$v['purchaseQty']]; ?></td>
                        <td><?php echo $product[$v['saleproduct']]; ?></td>
                        <td><?php echo $product[$v['saleQty']]; ?></td>
                       

                        <td>
                         
                            <a href="<?php echo base_url('reports/edit/'.$v['reportId']) ?>" class="btn btn-default"><i class="fa fa-edit"></i></a>
                         
                            <a href="<?php echo base_url('reports/delete/'.$v['reportId']) ?>" class="btn btn-default"><i class="fa fa-trash"></i></a>
                         
                        </td>
                     
                      </tr>
                    <?php endforeach ?>
                  <?php endif; ?>
                </tbody>
    </table>

                <br /> <br/>
	  </div>
	   </div>
	    </section>
		 </div>
		 <script>window.print();</script>